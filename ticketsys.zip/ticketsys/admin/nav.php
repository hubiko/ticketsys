<nav>
    <table>
        <tr><td><a class="nav"href="./index_admin.php?uid=<?php echo $id;?>">Tickety</a></td></tr> 
        <tr><td><a class="nav"href="./new_user.php?uid=<?php echo $id;?>">Nový klient</a></td></tr>        
        <tr><td><a class="nav"href="./new_op.php?uid=<?php echo $id;?>">Nový operátor</a></td></tr> 
        <tr><td><a class="nav"href="./new_company.php?uid=<?php echo $id;?>">Nová společnost</a></td></tr>    
        <tr><td><a class="nav"href="../logout.php">Odhlásit se</a></td></tr>
        
    </table>    
    
    
    
</nav>
