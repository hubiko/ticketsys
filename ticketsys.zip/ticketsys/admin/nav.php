<nav>
        <div class="admin_menu">
            <ul>
                <li><a class="nav"href="./index.php?uid=<?php echo $id;?>">Tickety</a>
                    <ul class='submenu'>
                        <li><a class="nav"href="./index.php?uid=<?php echo $id;?>">Otevřené</a></li>
                        <li><a class="nav"href="./tickets_ongo.php?uid=<?php echo $id;?>">Probíhající</a></li>
                    </ul>
                </li>
                <li>Nový
                    <ul class='submenu'>
                        <li><a class="nav"href="./new_user.php?uid=<?php echo $id;?>">Klient</a></li>
                        <li><a class="nav"href="./new_op.php?uid=<?php echo $id;?>">Operátor</a></li>
                        <li><a class="nav"href="./new_company.php?uid=<?php echo $id;?>">Společnost</a></li>
                    </ul>
                </li>
                <li><a class="nav"href="../logout.php">Odhlásit se</a></li>
            </ul> 
        </div>

          
    
    
    
</nav>
