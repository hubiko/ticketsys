<head>
<link rel="stylesheet" href="../css/main.css" type="text/css">
</head>
<body>
  
  <?php 
  include("../miniHeader.php");
  include("../header.php");
  $id = $_GET['uid'];
  include("../sidebar.php") ;
  ?>

<div class="content">
    <div class="cHeader">
      <h1 style="margin-left:2%; padding-top:40px;">Administrace</h1>
    </div>
    <div class="contentBackg">
        <div class="window">
            <div class="wHeader">
                <h3>Nová společnost</h3>
            </div>
            <div class="wContent">
                <form action='<?php $PHP_SELF;?>' method='post' id="admin">
                    <table>
                        <tr><td>Název:</td><td><input type="text" name="nazev"></td></tr>
                        <tr><td>Email:</td><td><input type="text" name="email"></td></tr>
                        <tr><td>Telefon:</td><td><input type="text" name="tel"></td></tr>
                        <tr><td><input type="submit" name="ok" value="Zaregistrovat"></td><td></td></tr>
                    </table>
                </form>
                <?php
                    if(isset($_POST["ok"])) {      
                        $nazev = $_POST["nazev"];
                        $email = $_POST["email"];
                        $tel = $_POST["tel"];
                        
                        if($nazev==null || $tel==null || $email==null) {
                            echo "Vyplňtě všechna políčka formuláře.";
                        } else { 
                            require_once("../classes/comps.php");
                            $add = new Company;
                            $add->AddCompany($nazev, $email, $tel);
                        } 
                    }  ?>   
            </div>                
                    
        </div>
        
    </div>
    
</div>
