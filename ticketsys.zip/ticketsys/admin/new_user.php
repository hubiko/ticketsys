<head>
<link rel="stylesheet" href="../css/main.css" type="text/css">
</head>
<body>
  
  <?php 
  include("../miniHeader.php");
  include("../header.php");
  $id = $_GET['uid'];
  include("../sidebar.php") ;
  ?>

<div class="content">
    <div class="cHeader">
      <h1 style="margin-left:2%; padding-top:40px;">Administrace</h1>
    </div>
    <div class="contentBackg">
        <div class="window">
            <div class="wHeader">
                <h3>Nový klient</h3>
            </div>
            <div class="wContent">
            <form method='post' id="admin">
                <table>
                    <tr><td>Jméno:</td><td><input type="text" name="name"></td></tr>
                    <tr><td>Příjmení:</td><td><input type="text" name="lastname"></td></tr>
                    <tr><td>Nick:</td><td><input type="text" name="nick"></td></tr>
                    <tr><td>Email:</td><td><input type="text" name="email"></td></tr>
                    <tr><td>Telefon:</td><td><input type="text" name="tel"></td></tr>
                    <tr><td>Společnost:</td><td><select id="comp" name="comp">
                    <?php 
                    require_once("../classes/comps.php");
                    $assign = new Company;
                    $assign->AssignCompany();
                    ?>
                    </select>
                    <tr><td><input type="submit" name="ok_R" value="Zaregistrovat"></td><td></td></tr>
                    </table>
            </form>

            <?php
                if(isset($_POST["ok_R"])) {
                    $name = $_POST["name"];
                    $lastname = $_POST["lastname"];
                    $nick = $_POST["nick"];
                    $pass = $_POST["nick"];
                    $email = $_POST["email"];
                    $tel = $_POST["tel"];
                    $comp = $_POST["comp"];
                    require_once('../classes/account.php');
                    $register = new Register($name, $lastname, $nick, $pass, $email, $tel, $comp);
                    $register->Add();				
                }
            ?>
            </div>
        
        </div>
    
    </div>
</div>