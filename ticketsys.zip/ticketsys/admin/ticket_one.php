<head>
<link rel="stylesheet" href="../css/main.css" type="text/css">
</head>
<body>
  
  <?php 
  include("../header.php");
  include("../miniHeader.php");
  $id = $_GET['uid'];
  include("../sidebar.php") ;
  ?>

<div class="content">
    <div class="cHeader">
      <h1 style="margin-left:2%; padding-top:40px;">Dashboard</h1>
    </div>
    <div class="contentBackg">
      <div class="window" id="ticketInfo">
            <h3>Info</h3>
            <div class="ticketHead">                <!--hlavička-->
                <div class="ticketHead_up">
                    <?php require_once("../classes/tickets.php");
                        $show = new Tickets;
                        $show->ShowTicketInfo();
                    ?>
                </div>
                <div class="ticketHead_down">
                  <?php 
                    require_once("../classes/tickets.php");
                    $show = new Tickets;
                    $show->ShowTicketUserInfo();
                  ?>
                </div>
            </div>
        </div>
      <div class="window" id="chat">
          <div class="wHeader">
            <h3>Diskuze</h3>
          </div>
          <div class="wContent">
            
            <div class="disc">                      <!--Diskuze-->
              <div class="discContent" id="discContent">
                <?php
                  require_once("../classes/tickets.php");
                  $show = new Tickets;
                  $show->ShowMsg();
                ?>
              </div>
            </div>                                        

            <div class="msg" id="msg">                       <!--zpráva-->
              <!--<script src="./button.js"></script>-->
              <div class="assign">
                <form method="post">
                  <table>
                    <tr>
                      <td><select name="op" id="op">
                          <?php require_once("../classes/users.php");
                          $show = new Users;
                          $show->ShowUsers();
                          ?>
                          </select></td>
                      <td><input type="submit" value="Přidělit" name="assign"></td>
                    </tr>                              
                  </table>
                </form>
                <?php
                  if(isset($_POST["assign"])) {
                    $nick = $_POST["op"];
                    require_once("../classes/users.php");
                          $assign = new Users;
                          $assign->Assign($nick);
                  }
                ?>
              </div>
            </div>
            
          </div>
        </div>
        
    </div>
