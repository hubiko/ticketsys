<head>
<link rel="stylesheet" href="../css/main.css" type="text/css">
</head>

  
  <?php 
  include("../header.php");
  include("../miniHeader.php");
  $id = $_GET['uid'];
  include("../sidebar.php") ;
  if(isset($_SESSION["id"])==null)
      header("location:../index.php"); 
  ?>
  ?>
  <div id="hamburger">
    <?php
    $i = $_SESSION["autor"]; 
      if($i==1)
        include("E:/Ondra/xampp/htdocs/ticketsys/admin/nav.php");
      if($i==2)
        include("E:/Ondra/xampp/htdocs/ticketsys/op/nav.php");
      if($i==3)
        include("E:/Ondra/xampp/htdocs/ticketsys/user/nav.php");
    ?>
    
  </div>

<div class="content">
    <div class="cHeader">
      <h1 style="margin-left:2%; padding-top:40px;">Dashboard</h1>
    </div>
    <div class="contentBackg">
      <div class="window" id="ticketInfo">
        <div class="wHeader">
          <h3>Tiket</h3>
        </div>
        <div class="wContent">
          <div class="ticketHead">                <!--hlavička-->
                  <div class="ticketHead_up">
                      <?php require_once("../classes/tickets.php");
                          $show = new Tickets;
                          $show->ShowTicketInfo();
                      ?>
                  </div>
                  <h3>Uživatel</h3>
                  <div class="ticketHead_down">
                    <?php 
                      require_once("../classes/tickets.php");
                      $show = new Tickets;
                      $show->ShowTicketUserInfo();
                    ?>
                  </div>
              </div>
          </div>
        </div>
            
            
      <div class="window" id="chat">
          <div class="wHeader">
            <h3>Diskuze</h3>
          </div>
          <div class="wContent">
            
            <div class="disc">                      <!--Diskuze-->
              <div class="discContent" id="discContent">
                <?php
                  require_once("../classes/tickets.php");
                  $show = new Tickets;
                  $show->ShowMsg();
                ?>
              </div>
            </div>                                        

            <div class="msg" id="msg">                       <!--zpráva-->
              <!--<script src="./button.js"></script>-->
              <div class="assign">
                <form method="post">
                  <table>
                    <tr>
                      <td><select name="op" id="op">
                          <?php require_once("../classes/users.php");
                          $show = new Users;
                          $show->ShowUsers();
                          ?>
                          </select></td>
                      <td><input type="submit" value="Přidělit" name="assign"></td>
                    </tr>                              
                  </table>
                </form>
                <?php
                  if(isset($_POST["assign"])) {
                    $nick = $_POST["op"];
                    require_once("../classes/users.php");
                          $assign = new Users;
                          $assign->Assign($nick);
                  }
                ?>
              </div>
            </div>
            
          </div>
        </div>

        <div class="window">
                  <div class="wHeader">
                    <h3>Operátoři</h3>
                  </div>
                  <div class="wContent" id="ticketScroll">
                  
                    <table>
                      <tr>
                        <th>ID</th>
                        <th>Jméno</th>
                        <th>Příjmení</th>
                        <th>Kategorie</th>
                        <th>Aktivní tikety</th>
                      </tr>
                      <?php
                        require_once("../classes/users.php");
                        $op = new Users;
                        $op->OpStates();
                      ?>
                    </table>
                  </div>
          <div class='op_table'>
              <div class='op_table_cont'>
              
              </div>
          </div>      
        </div>
        
        
    </div>
