<head>
<link rel="stylesheet" href="../css/main.css" type="text/css">
</head>
<body>
  
  <?php 
  include("../miniHeader.php");
  include("../header.php");
  $id = $_GET['uid'];
  include("../sidebar.php") ;
  if(isset($_SESSION["id"])==null)
      header("location:../index.php"); 
  ?>
  ?>
  <div id="hamburger">
    <?php
    $i = $_SESSION["autor"]; 
      if($i==1)
        include("E:/Ondra/xampp/htdocs/ticketsys/admin/nav.php");
      if($i==2)
        include("E:/Ondra/xampp/htdocs/ticketsys/op/nav.php");
      if($i==3)
        include("E:/Ondra/xampp/htdocs/ticketsys/user/nav.php");
    ?>
    
  </div>
  

  <div class="content">
    <div class="cHeader">
      <h2 style="margin-left:2%; padding-top:40px;">Administrace</h2>
    </div>
    <div class="contentBackg">
      <div class="cont-1c">
          <div class="window">
              <div class="wHeader">
                <h3>Probíhající tikety</h3>
              </div>
              <div class="wContent" id='ticketScroll'>
              <table class="admin">
              <?php
                    require_once("../classes/tickets.php");          
                      $tickets = new Tickets;
                      $tickets->ShowPart();               
                    
                ?>
              </table>
        </div>
            
        </div>
      </div>
      
    
    </div>
  </div>