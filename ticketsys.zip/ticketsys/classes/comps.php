<?php
class Company {
    public $link;
    public function AddCompany($nazev, $tel, $email) {
        include("../connectDB.php");
        $insert = mysqli_query($this->link, "insert into spolecnost values (null, '$nazev', '$tel', '$email')");
            if($insert)
              echo "Registrace proběhla úspěšně";
            else 
              echo "!!!";
    }
}
?>