<?php
class Company {
    public $link;
    public function AddCompany($nazev, $email, $tel) {
        include("../connectDB.php");
        $insert = mysqli_query($this->link, "insert into spolecnost values (null, '$nazev', '$tel', '$email')");
            if($insert)
              echo "Registrace proběhla úspěšně";
            else 
              echo "!!!";
    }
    public function AssignCompany() {
      include("../connectDB.php");
      $query = mysqli_query($this->link, "select * from spolecnost");
      foreach($query as $q) {
          echo "<option>".$q["nazev"]."</option>";
      }
    }
}
?>