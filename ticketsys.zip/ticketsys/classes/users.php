<?php
    class Users {
        public $link;
        public function Assign($nick) {
            include("../connectDB.php");
            $ticket_id = $_GET["tid"];
            $users = mysqli_query($this->link, "select * from uzivatele where nick='$nick'");
            foreach($users as $u) {
                $user_id = $u["id"];
            }                
            $update = mysqli_query($this->link, "update tickety set pridelen_ID=$user_id where id=$ticket_id");
            if($update) {
                echo "Ticket přidělen operátorovi $nick";
                $update = mysqli_query($this->link, "update tickety set statusuje_id=2 where id=$ticket_id");
            }
                
        }
        public function getCategoryId($cat) {
            include("../connectDB.php");
            $cat_query = mysqli_query($this->link, "select id from kategorie where typ='$cat'");
            while($cat_db = mysqli_fetch_object($cat_query)) {
              $category_id = $cat_db->id;
            }  
            return $category_id;              
        }

        public function AddOp($name, $lastname, $nick, $pass, $email, $tel, $cat) {
            if($name==null || $lastname==null || $nick==null || $email==null || $tel==null || $cat==null) {
                echo "Vyplňtě všechna políčka formuláře.";
            } 
            else {
                include ("../connectDB.php");
                    $pass = md5(md5($pass));
                    $zapis = mysqli_query($this->link, "insert into uzivatele values (null, 
                    '$name', '$lastname', '$nick', 
                    '$pass', '$email', '$tel', ".$this->getCategoryId($cat).", null, 2)");
                    if($zapis)
                      echo "Registrace proběhla úspěšně";
                  
            }
        }

        public function OpStates() {
            include("../connectDB.php");
            $q = mysqli_query($this->link, "select * from uzivatele where autorizuje_id=2");
            while($op=mysqli_fetch_object($q)) {
                $id = $op->id;
                $name = $op->jmeno;
                $lastname = $op->prijmeni;
                $cat_id = $op->kategorie_id;
                $category = mysqli_query($this->link, "select * from kategorie where id=$cat_id");
                $c = mysqli_fetch_object($category);
                $cat = $c->typ;
                $q1 = mysqli_query($this->link, "select * from tickety where pridelen_ID=$id 
                and statusuje_id<4");
                $i = 0;
                $tickets = array();
                while($t=mysqli_fetch_object($q1)) {
                    $tickets[$i] = 1;
                    $i++;
                }
                $count = count($tickets);
                echo "<tr>
                            <td>$id</td><td>$name</td><td>$lastname</td><td>$cat</td><td>$count</td>
                    </tr>";
            }
            echo "</table>";
        }

        public function ShowUsers() {
            include("../connectDB.php");
            $users = mysqli_query($this->link, "select nick from uzivatele where autorizuje_id=2");
            foreach($users as $u) {
                $user = $u["nick"];
                echo "<option name='users' value='$user'>$user</option>";
            }
        }
    }
?>