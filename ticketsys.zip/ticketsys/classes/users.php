<?php
    class Users {
        public $link;
        public function Assign($nick) {
            include("../connectDB.php");
            $ticket_id = $_GET["tid"];
            $users = mysqli_query($this->link, "select * from uzivatele where nick='$nick'");
            foreach($users as $u) {
                $user_id = $u["id"];
            }                
            $update = mysqli_query($this->link, "update tickety set pridelen_ID=$user_id where id=$ticket_id");
            if($update)
                echo "Ticket přidělen operátorovi $nick";

            echo $nick, $user_id, $ticket_id;
        }
        public function ShowUsers() {
            include("../connectDB.php");
            $users = mysqli_query($this->link, "select nick from uzivatele where autorizuje_id=2");
            foreach($users as $u) {
                $user = $u["nick"];
                echo "<option name='users' value='$user'>$user</option>";
            }
        }
    }
?>