<?php
    class Users {
        public $link;
        public function Assign($nick) {
            include("../connectDB.php");
            $ticket_id = $_GET["tid"];
            $users = mysqli_query($this->link, "select * from uzivatele where nick='$nick'");
            foreach($users as $u) {
                $user_id = $u["id"];
            }                
            $update = mysqli_query($this->link, "update tickety set pridelen_ID=$user_id where id=$ticket_id");
            if($update) {
                echo "Ticket přidělen operátorovi $nick";
                $update = mysqli_query($this->link, "update tickety set statusuje_id=2 where id=$ticket_id");
            }
                
        }

        public function AddOp($name, $lastname, $nick, $pass, $email, $tel) {
            if($name==null || $lastname==null || $nick==null || $email==null || $tel==null) {
                echo "Vyplňtě všechna políčka formuláře.";
            } 
            else {
                include ("../connectDB.php");
                    $pass = md5(md5($pass));
                    $zapis = mysqli_query($this->link, "insert into uzivatele values (null, 
                    '$name', '$lastname', '$nick', 
                    '$pass', '$email', '$tel', null, 2)");
                    if($zapis)
                      echo "Registrace proběhla úspěšně";
                  
            }
        }

        public function ShowUsers() {
            include("../connectDB.php");
            $users = mysqli_query($this->link, "select nick from uzivatele where autorizuje_id=2");
            foreach($users as $u) {
                $user = $u["nick"];
                echo "<option name='users' value='$user'>$user</option>";
            }
        }
    }
?>