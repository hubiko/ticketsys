<?php
     $this->link = mysqli_connect('localhost:4306', 'root', '', 'tickety');
     mysqli_query($this->link, "SET NAMES 'utf8'");
?>