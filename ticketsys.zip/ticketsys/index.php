<head>
<link rel="stylesheet" href="./css/main.css" type="text/css">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

    <?php     session_start();
            if(isset($_SESSION["nick"])) {              //když jsi přihlášený, nemusíš se znovu přihlásit
            $link = mysqli_connect('localhost:3307', 'root', '', 'tickety');
            $dotaz = mysqli_query($link, "select * from uzivatele where id=".$_SESSION["id"]."");
            foreach($dotaz as $d) {
                $autor = $d["autorizuje_id"];
            }
            if($autor==3) {
              header("Location: ./user/index.php?uid=".$_SESSION["id"]."");
              }
             if($autor==2) {
              header("Location: ./op/index.php?uid=".$_SESSION["id"].""); 
             }
             if($autor==1) {
                 header("Location: ./admin/index.php?uid=".$_SESSION["id"]."&stat=1"); 
                }
                
                
          }?>

          <div class="main" style="overflow: hidden; width: 100%; height: 100%;">
        <div class="loginContent" style="margin: auto; margin-top: 15%; width: 90%;">
                    
                    <div class="window" style="margin: auto; padding: 2.5% 2.5% 2.5% 2.5%; width: 100%;
                    border: 1px solid black;">
                        <form action='#' method='post' class='frm' style="width: 50%; margin: auto;">

                                <h2>Přihlášení:</h2>  
                                <tr><td>Nick:</td><td><input type='text' name='nick'></td></tr>
                                <tr><td>Heslo:</td><td><input type='password' name='pass'></td></tr><br> 
                                <tr><td><input type='submit' name='ok_L' value='Přihlásit se'></td><td></td></tr>

                        </form>
                    </div>
                        
                    
                    <br>
                
                <?php
                    
                    
                    if(isset($_POST["ok_L"])) {
                        $nick = $_POST["nick"];
                        $pass = $_POST["pass"];
                        require_once('./classes/account.php');
                        $login = new Login($nick, $pass);
                        $login->LogIn();				
                    }         
                ?>
            </div>
          </div>

          
          
          
  </body>
</html>