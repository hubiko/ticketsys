<div class="miniheader">
    <a href="javascript:void(0);" class="icon" onclick='var x = document.getElementById("hamburger");
    if (x.style.display === "block") {
      x.style.display = "none";
    } else {
      x.style.display = "block";
    }' style="float: right; margin-top: 7px;">
      <img class="hamenu" src="../img/hamburger.png" width="30px">
    </a>
  </div>