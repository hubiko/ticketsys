<head>
<link rel="stylesheet" href="../css/main.css" type="text/css">
</head>
<body>
  
  <?php 
  include("../miniHeader.php");
  include("../header.php");
  $id = $_GET['uid'];
  include("../sidebar.php") ;
  ?>

  <div class="content">
    <div class="cHeader">
      <h1 style="margin-left:2%; padding-top:40px;">Operátor</h1>
    </div>
    <div class="contentBackg">
      <div class="window">
          <div class="wHeader">
            <h3>Nový ticket</h3>
          </div>
          <div class="wContent">
		  <table id="admin"> 
      <?php
                require_once("../classes/tickets.php");
                $tickets = new Tickets();
                $tickets->ShowPart();
            ?>
    </div>
        
    </div>
    
    </div>
  </div>
  


