<nav>
    <table>
     
            
        <tr><td><a class="nav"href="../logout.php">Odhlásit se</a></td></tr>
        
    </table>    
    
    
    
</nav>
