<?php 
include("../header.php");
$id = $_GET['uid'];
include("../miniHeader.php");
include("../sidebar.php");
if(isset($_SESSION["id"])==null)
      header("location:../index.php"); 
  ?>?>

<head>
    <link rel="stylesheet" href="../css/main.css" type="text/css">
</head>
<div id="hamburger">
    <?php
    $i = $_SESSION["autor"]; 
      if($i==1)
        include("E:/Ondra/xampp/htdocs/ticketsys/admin/nav.php");
      if($i==2)
        include("E:/Ondra/xampp/htdocs/ticketsys/op/nav.php");
      if($i==3)
        include("E:/Ondra/xampp/htdocs/ticketsys/user/nav.php");
    ?>
    
  </div>

<body>
    <?php
                    
    ?>

    <div class="content">
        <div class="cHeader">
            <h1 style="margin-left:2%; padding-top:40px;">Uzavřené tikety</h1>
        </div>
        <div class="contentBackg">
            <div class="window" id='ticketScroll'>
                <table>
                <?php
                    require_once("../classes/tickets.php");
                    $tickets = new Tickets();
                    $tickets->ShowPart();
                ?>
        </div>
        </div>
        
    </div>
</body>