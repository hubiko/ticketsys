<div class="sidebar">
    <div class="sHeader">
      <h3 style="margin-left:2%; color:white;padding-top:40px;">Ticket s.r.o.</h3>
    </div>
    <?php 
      include "./nav.php";
    ?>
</div>

<div class="sidebar_s">
    <div class="sHeader">
      
    </div>
</div>