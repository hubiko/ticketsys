<div class="sidebar">
    <div class="sHeader">
      <h1 style="margin-left:2%; color:white;padding-top:40px;">LOGO</h1>
    </div>
    <?php 
      include "./nav.php";
    ?>
</div>

<div class="sidebar_s">
    <div class="sHeader">
      
    </div>
</div>