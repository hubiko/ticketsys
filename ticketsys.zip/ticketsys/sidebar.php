<div class="sidebar">
    <div class="sHeader">
      <h1 style="margin-left:2%; color:white;">LOGO</h1>
    </div>
    <?php 
      include "./nav.php";
    ?>
</div>