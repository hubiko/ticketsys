
<div class="menu">
    <div class="manu_main">
        <ul>
            <li id="li_tickety">Tickety</li>
            <li id="li_new">Nový</li>
        </ul>
    </div>
    <div class="menu_sub">
        <ul id="ul_tickety">
            <li>Tickety</li>
            <li>Probíhající tickety</li>
        </ul>
        <ul class="ul_new">
            <li>Klient</li>
            <li>Operátor</li>
            <li>Společnost</li>
        </ul>
    </div>
</div>

<style>
    .menu {
    float: left;
	width:400px;
	background-color: #2A2C2D;
	height: 100%;
    position: fixed; 
    color:white; 
    display: flex;
    }
    .menu_main {
        width:160px;
        height: 60%;
        float: left;
    }

    .menu_sub {
        width:160px;
        height: 60%;
        float: right;
    }
</style>

