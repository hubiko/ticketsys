<?php 
        // $msg = $_REQUEST["msg"];
        //     include("../connectDB.php");
        //     $this->ticket_id = $this->getId_ticket();
        //     $this->user_id = $this->getUser_id();
        //     $this->autor_id = $this->getAutor_id();
        //     $this->date = $this->getDate();
        //     $this->msg = $msg;
        //     $this->insert = mysqli_query($this->link, "insert into zpravy values (null, '$this->ticket_id', '$this->user_id', '$this->autor_id', '$this->date', '$this->msg')");
        echo("sad");

?>
