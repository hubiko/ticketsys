let button = document.getElementById("ok");
let div = document.getElementById("discContent");
let zprava = document.getElementById("zprava");
button.onclick = function(){console.log("abdsf")
let block = document.createElement("div");

block.classList.add("msg_client");
block.innerHTML=zprava.value;
div.appendChild(block);
loadDoc("asd");


};

function loadDoc(msg) {
   
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {

      }
    };
    xhttp.open("GET", "add.php", true);
    xhttp.send();
    console.log("Povedlo se");
  }
