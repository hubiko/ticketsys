
<div class="admin_menu">
            <ul>
                <li><a class="nav"href="./index.php?uid=<?php echo $id;?>">Nový tiket</a>
                <li><a class="nav"href="./ticket_view.php?uid=<?php echo $id;?>&stat=1">Tikety</a><span style="font-size: 180%;" class="plus"> &ensp; +</span> 
                    <ul class='submenu'>
                        <li><a class="nav"href="./ticket_closed.php?uid=<?php echo $id;?>&stat=4">Uzavřené</a></li>
                    </ul>
                </li>
                <li><a class="nav"href="../logout.php">Odhlásit se</a></li>
            </ul> 
        </div>
