<nav>
    <table>
        <tr>
            <td><a class="nav"href="./index_user.php?uid=<?php echo $id;?>">Nový ticket</a></td></tr>
        <tr><td><a class="nav"href="./ticket_view.php?uid=<?php echo $id;?>">Mé tickety</a></td></tr>
        <tr><td><a class="nav"href="../logout.php">Odhlásit se</a></td></tr>
        
    </table>    
    
    
    
</nav>
