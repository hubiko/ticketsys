<?php 
$id = $_GET['uid'];
include("../miniHeader.php");
include("../header.php");
include("../sidebar.php");
if(isset($_SESSION["id"])==null)
      header("location:../index.php"); 
  ?>

<div id="hamburger">
    <?php
    $i = $_SESSION["autor"]; 
      if($i==1)
        include("E:/Ondra/xampp/htdocs/ticketsys/admin/nav.php");
      if($i==2)
        include("E:/Ondra/xampp/htdocs/ticketsys/op/nav.php");
      if($i==3)
        include("E:/Ondra/xampp/htdocs/ticketsys/user/nav.php");
    ?>
    
  </div>

<head>
    <link rel="stylesheet" href="../css/main.css" type="text/css">
</head>

<body>

    <div class="content">
        <div class="cHeader">
            <h3 style="margin-left:2%; padding-top:40px;">Přihlášen: <span style="color: #ce1b28;"><?php echo $_SESSION["nick"]?></span></h3>
        </div>
        <div class="contentBackg">
            <div class="cont-1c">
                    <div class="window" id='ticketScroll'>
                        <div class="wHeader">
                            <h4>Uzavřené tikety</h4>
                        </div>
                        <div class="wContent">
                            <table>
                            <?php
                                require_once("../classes/tickets.php");
                                $tickets = new Tickets();
                                $tickets->ShowPart();
                            ?>
                        </div>
                        
                    </div>
                </div>
            </div>
            
        
    </div>
</body>