<head>
<link rel="stylesheet" href="../css/main.css" type="text/css">
</head>
<body>
  
  <?php 
  include("../header.php");
  include("../miniHeader.php");
  $id = $_GET['uid'];
  include("../sidebar.php") ;
  ?>

<div class="content">
    <div class="cHeader">
      <h1 style="margin-left:2%; padding-top:40px;">Dashboard</h1>
    </div>
    <div class="contentBackg">
      <div class="window" id="chat">
          <div class="wHeader">
            <h3>Diskuze</h3>
          </div>
          <div class="wContent">
            
            <div class="disc">                      <!--Diskuze-->
              <div class="discContent" id="discContent">
                <?php
                  require_once("./tickets.php");
                  $show = new Tickets;
                  $show->ShowMsg();
                ?>
              </div>
            </div>                                        

            <div class="msg" id="msg">                       <!--zpráva-->
              <form method="post">
                <table>
                  <tr><td><textarea rows=1 cols=50 name="zprava" id="zprava"></textarea></td>
                  <td><input type="submit" name="ok" id="ok"></td></tr>                               
                </table>
              </form>
              <?php 
                  if(isset($_POST["ok"])) {
                    if(isset($_POST["zprava"])) {
                      $msg = $_POST["zprava"];
                      require_once("./tickets.php");
                      $addMsg = new Tickets;
                      $addMsg->AddMsg($msg);
                    }
                  }
              ?>
              <!--<script src="./button.js"></script>-->
            </div>
            
          </div>
        </div>
        <div class="window" id="ticketInfo">
            <h3>Info</h3>
            <div class="ticketHead">                <!--hlavička-->
                <div class="ticketHead_up">
                    <?php require_once("./tickets.php");
                        $show = new Tickets;
                        $show->ShowTicketInfo();
                    ?>
                </div>
                <div class="ticketHead_down">
                  <?php 
                    require_once("./tickets.php");
                    $show = new Tickets;
                    $show->ShowTicketUserInfo();
                  ?>
                </div>
            </div>
          </div>
    </div>
