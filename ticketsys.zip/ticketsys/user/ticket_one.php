<head>
<link rel="stylesheet" href="../css/main.css" type="text/css">
</head>
<body>
  
  <?php 
  include("../miniHeader.php");
  $id = $_GET['uid'];
  include("../sidebar.php") ;
  ?>

<div class="content">
    <div class="cHeader">
      <h1 style="margin-left:2%; padding-top:40px;">Dashboard</h1>
    </div>
    <div class="contentBackg">
      <div class="window">
          <div class="wHeader">
            <h3>Ticket</h3>
          </div>
          <div class="wContent">

            <div class="ticketHead">                <!--hlavička-->
                <div class="ticketHead_left">
                </div>
                <div class="ticketHead_right">
                    <?php require_once("./tickets.php");
                        $show = new Tickets;
                        $show->ShowTicketInfo();
                    ?>
                </div>
            </div>
            
            <div class="disc">                      <!--Diskuze-->
            
            </div>                                        

            <div class="msg">                       <!--zptáva-->
            
            </div>
            
          </div>
        </div>
    </div>
