<head>
<link rel="stylesheet" href="../css/main.css" type="text/css">
</head>
<body>
  
  <?php 
  include("../header.php");
  include("../miniHeader.php");
  $id = $_GET['uid'];
  $tid = $_GET["tid"];
  include("../sidebar.php") ;
  if(isset($_SESSION["id"])==null)
      header("location:../index.php");
  ?>
  <div id="hamburger">
    <?php
    $i = $_SESSION["autor"]; 
      if($i==1)
        include("E:/Ondra/xampp/htdocs/ticketsys/admin/nav.php");
      if($i==2)
        include("E:/Ondra/xampp/htdocs/ticketsys/op/nav.php");
      if($i==3)
        include("E:/Ondra/xampp/htdocs/ticketsys/user/nav.php");
    ?>
    
  </div>

<div class="content">
    <div class="cHeader">
      <h3 style="margin-left:2%; padding-top:40px;">Přihlášen: <span style="color: #ce1b28;"><?php echo $_SESSION["nick"]?></span></h3>
    </div>
    <div class="contentBackg">
      <div class="window" id="ticketInfo">
          <div class="wHeader">
            <h3>Info</h3>
          </div>
          <div class="wContent">
            <div class="ticketHead">                <!--hlavička-->
                  <div class="ticketHead_up">
                      <?php require_once("../classes/tickets.php");
                          $show = new Tickets;
                          $show->ShowTicketInfo();
                      ?>
                  </div>
                  <div class="ticketHead_down">
                    <?php 
                      require_once("../classes/tickets.php");
                      $show = new Tickets;
                      $show->ShowTicketUserInfo();
                    ?>
                  </div>
              </div>
          </div>
            
            
        </div>
      <div class="window" id="chat">
          <div class="wHeader">
            <div class="chatHeader_left">
              <h3>Diskuze</h3>
            </div>
            <div class="chatHeader_right">
              <?php
                if(isset($_GET['close'])) {
                  require_once("../classes/tickets.php");
                  $change = new Tickets;
                  $change->ChangeStatus();
                  if($change)
                    echo "Tiket uzavřen!";
                  else 
                    echo "!!!";
                }
              ?>
              <?php require_once("../classes/tickets.php"); $stat = new Tickets; $status = $stat->getStatus_id();?>
              <a href="./ticket_one.php?uid=<?php echo $_SESSION['id'];?>
                    &tid=<?php echo $tid;?>&close=true">
                    <h5 id='close' style='padding-top: 10px; color: #ce1b28;<?php  
                    if(isset($_GET["close"]) || $status!=3) {
                      echo "display: none;"; 
                    }?>'>Uzavřít tiket <img src="../img/close-button.png" width='17px' 
              alt=""></h5></a>        
            </div>            
            
          </div>
          <div class="wContent">
            
            <div class="disc">                      <!--Diskuze-->
              <div class="discContent" id="discContent">
                <?php
                  require_once("../classes/tickets.php");
                  $show = new Tickets;
                  $show->ShowMsg();
                ?>
              </div>
            </div>                                        

            <div class="msg" id="msg">                       <!--zpráva-->
              <form method="post">
                <table>
                  <tr><td><textarea rows=1 cols=50 name="zprava" id="zprava"></textarea></td>
                  <td><input type="submit" name="ok" id="ok"></td></tr>                               
                </table>
              </form>
              <?php 
                  if(isset($_POST["ok"])) {
                    if(isset($_POST["zprava"])) {
                      $msg = $_POST["zprava"];
                      require_once("../classes/tickets.php");
                      $addMsg = new Tickets;
                      $addMsg->AddMsg($msg);
                    }
                  }
              ?>
              <!--<script src="./button.js"></script>-->
            </div>
            
          </div>
        </div>
        
    </div>
