
<div id='main'>
  <div id='container_ticket'>
    <div id='container_tick'>
    

<?php
    session_start();
    $id_ticket = $_GET["tid"];
    $link = mysqli_connect('127.0.0.1:3306', 'root', '', 'tickety');
    $dotaz = mysqli_query($link, "select * from tickety where id='$id_ticket'");
    foreach($dotaz as $d) {
      $predmet = $d["predmet"]; 
      $zpravaDef = $d["popisek"]; 
      $kategorie_id = $d["kategorizuje_id"]; 
      $uzivatel_id = $d["ma_uzivatele_id"]; 
      $status_id = $d["statusuje_id"]; 
      $datum = $d["datum"];
    }
          $d_u = mysqli_query($link, "select * from uzivatele where id='$uzivatel_id'");
          $zaznam = mysqli_fetch_object($d_u);
          $id_uzivatele = $zaznam->id;
          $jmeno = $zaznam->jmeno;
          $email = $zaznam->email;
          
          $d_c = mysqli_query($link, "select * from kategorie where id=".$d["kategorizuje_id"]."");
          $zaznam = mysqli_fetch_object($d_c);
          $cat = $zaznam->typ;
          
?>   <h1><?php echo $predmet;?> </h1>
    <div id="hlavicka_ticket">                               <!--hlavička-->
      <div id='hlavicka_left'>
        <?php
          echo "<table> <tr><td class='hlavicka_left'>ID uživatele:<td> $id_uzivatele</td> <tr>
            <tr><td>Jméno:<td>$jmeno</td><tr>
            <tr><td>Email:<td>$email</td><tr>
            <tr><td>Datum:<td>$datum</td><tr>
            </table>";
        ?>
      </div>
      <div id='hlavicka_right'>
        <?php
          echo "<table> <tr><td>ID ticketu:</td><td>$id_ticket</td><tr>
            <tr><td>Předmět:</td><td>$predmet</td><tr>
            <tr><td>Kategorie:</td><td>$cat</td><tr>
            </table>";
        ?>
      </div>
    </div>

      <form method='post'>                                                             <!--Uzavřít ticket-->
        <input type='submit' name='close' value='Uzavřít ticket' id='close'>
        <?php
           if(isset($_POST['close'])) {
              $status_id=3;
              $update = mysqli_query($link, "update tickety set statusuje_id=3 where id='$id_ticket'");
              if($update)
                echo "Ticket uzavřen!";
              else
                echo "!!!";
           }
        ?> 
      </form>              
      <div id="diskuze">                                    <!--Diskuze-->                      
        <div class='msg_user'>
          <p><?php echo $zpravaDef;?></p>
        </div>
      
      <?php
          $dotazZ = mysqli_query($link, "select * from zpravy where id_ticketu=$id_ticket");
          foreach($dotazZ as $dz) {
            $zprava = $dz["zprava"];
            $autor = $dz["id_autorizace"];
            if($autor==3) {
              echo "<div class='msg_user'>";
                  echo $zprava;  
              echo "</div>";
            }  else {
               echo "<div class='msg_admin'>";
                  echo $zprava;
               echo "</div>";       
            }

            
             
          }
        ?> 
      </div>
          <div id="zprava">                    <!--zpráva-->
            <form method="post">
                <textarea rows=10 cols=50 name="zprava1"> 
                </textarea>
                <input type="submit" name="ok">
              </table>
            </form>
            <?php
              if(isset($_POST["ok"])) {
                $zprava = $_POST["zprava1"];
                $autor = $_SESSION["autorizuje_id"];
                if($zprava==null) {
                  echo "Vyplňtě políčko.";
                } else {
                    $zapis = mysqli_query($link, "insert into zpravy values (null, '$id_ticket', '$id_uzivatele', '$autor', '$datum', '$zprava')");
                    if($zapis)
                      echo "Zpráva přidána!";
                    else 
                      echo "!!!";
                }
              }
            ?>
          </div>
    </div>
  </div>
</div>