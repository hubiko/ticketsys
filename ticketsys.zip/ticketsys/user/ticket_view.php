<?php 
session_start();
$id = $_GET['uid'];?>

<head>
    <link rel="stylesheet" href="../css/main.css" type="text/css">
</head>

<body>
    <?php
        include("../sidebar.php");            
    ?>

    <div class="content">
        <div class="cHeader">
        
        </div>
        <div class="window">
            <?php
                require_once("./tickets.php");
                $tickets = new Tickets();
                $tickets->ShowPart();
            ?>
        </div>
    </div>
</body>
