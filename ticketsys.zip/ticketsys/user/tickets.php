<?php
    class Tickets {
        public $user_id, $subject, $desc, $ticket_query, $status_query, $status_c, $q, 
        $record, $id_ticket, $cat_query, $autor_id,
        $status_id, $date, $category_id, $link, $name, $lastname;

        public function getId_ticket()
        {
            $this->id_ticket = $_GET["tid"];
            return $this->id_ticket;
        }
        /**
         * Get the value of user_id
         */ 
        public function getUser_id()
        {
            $this->id_ticket = $this->getId_ticket();
            $this->q = mysqli_query($this->link, "select * from tickety where 
             id='$this->id_ticket'");
            $this->record = mysqli_fetch_object($this->q); 
            $this->user_id = $this->record->ma_uzivatele_id;
            return $this->user_id;
        }

        

        public function ShowPart() { 
            include("../connectDB.php");
            echo "<table>
            <tr>
                <th>ID</th><th>Název</th><th>Kategorie</th><th>Status</th><th></th>
            </tr>";
             $this->ticket_query = mysqli_query($this->link, "select * from tickety where 
             ma_uzivatele_id=".$_SESSION['id']." order by id desc limit 4");
             foreach($this->ticket_query as $this->q) {             
                 $this->cat_query = mysqli_query($this->link, "select * from kategorie where 
                 id=".$this->q["kategorizuje_id"]."");
                 $this->record = mysqli_fetch_object($this->cat_query);
                 $this->category = $this->record->typ;            
                 
                 $this->status_query = mysqli_query($this->link, "select * from statusy where 
                 id=".$this->q["statusuje_id"]."");
                 $this->record = mysqli_fetch_object($this->status_query);
                 $this->status = $this->record->nazev;
                 $this->status_c = $this->record->barva;
                 
                 $this->user_query = mysqli_query($this->link, "select * from uzivatele where 
                 id=".$this->q["ma_uzivatele_id"]."");
                 $this->record = mysqli_fetch_object($this->user_query);
                 $this->user = $this->record->nick;
                 $this->id_ticket = $this->q["id"];
                 echo "<tr><td>".$this->q["id"]."</td><td>".$this->q["predmet"]."</td><td>$this->category</td>
                 <td style='background-color: $this->status_c; color: white;'>$this->status</td>
                 <td><a href='./ticket_one.php?uid=".$_SESSION['id']."
                 &tid=$this->id_ticket'><h2>+</h2></a></td></tr>";
             }
             echo "</table>";                             
         }
         
         
         public function ShowTicketInfo() {
            $this->ticket_id = $this->getId_ticket();
            include("../connectDB.php");
            $this->ticket_query = mysqli_query($this->link, "select * from tickety where 
            id='$this->id_ticket'");
            foreach($this->ticket_query as $this->q) {
                $this->subject = $this->q["predmet"]; 
                $this->desc = $this->q["popisek"]; 
                $this->category_id = $this->q["kategorizuje_id"]; 
                $this->autor_id = $this->q["ma_uzivatele_id"]; 
                $this->status_id = $this->q["statusuje_id"]; 
                $this->date = $this->q["datum"];
              }
              /*$this->q = mysqli_query($this->link, "select * from uzivatele where 
              id='$this->autor_id'");
              $this->record = mysqli_fetch_object($this->q);
              $this->name = $this->record->jmeno;
              $this->lastname = $record->prijmeni;
              $this->nick = $record->nick;
              $this->email = $record->email;*/
              
              $this->q = mysqli_query($this->link, "select * from kategorie where 
              id='$this->category_id';");
              $this->record = mysqli_fetch_object($this->q);
              $this->category = $this->record->typ;

              echo "<table> <tr><td>ID ticketu:</td><td>$this->ticket_id</td><tr>
                <tr><td>Předmět:</td><td>$this->subject</td><tr>
                <tr><td>Kategorie:</td><td>$this->category</td><tr>
                </table>";
        }
        
        public function ShowTicketUserInfo() {
            include("../connectDB.php");
            $this->user_id = $this->getUser_id();            
            $this->user_query = mysqli_query($this->link, "select * from uzivatele where 
            id='$this->user_id';");
            $this->record = mysqli_fetch_object($this->user_query);
                $this->user_id = $this->user_id;
                $this->name = $this->record->jmeno;
                $this->lastname = $this->record->prijmeni;
                $this->nick = $this->record->nick;
                $this->email = $this->record->email;
            echo "<table> <tr><td>ID:</td><td>$this->user_id</td><tr>
                <tr><td>Jméno:</td><td>$this->name</td><tr>
                <tr><td>Příjmení:</td><td>$this->lastname</td><tr>
                <tr><td>Nickname:</td><td>$this->nick</td><tr>
                <tr><td>Email:</td><td>$this->email</td><tr>
                </table>";
        }
        public function AddMsg($msg) {
            $this->msg = $msg;
            include("../connectDB.php");
            $this->insert = mysqli($this->link, "insert into zpravy set id_ticketu='".$this->getId_ticket()."' id_uzivatele='' id_autorizace='' datum='' zprava=''");
        }

        public function ShowTicketMsg() {
            
        }


    }

    class Ticket extends Tickets {
        public $id, $category, $mail, $user_id,  $cat_query, $cat_db, $insert, $status, $msg;

        public function __construct($subject, $category, $desc, $mail) {
            $this->subject = $subject;
            $this->category = $category;
            $this->desc = $desc;
            $this->mail = $mail;
        }

        public function getUserId() {
            session_start();
            $this->user_id = $_SESSION["id"];
            return $this->user_id;
        }
        public function getCategoryId() {
            include("../connectDB.php");
            $this->cat_query = mysqli_query($this->link, "select id from kategorie where typ='$this->category'");
            while($this->cat_db = mysqli_fetch_object($this->cat_query)) {
              $this->category_id = $this->cat_db->id;
            }  
            return $this->category_id;              
        }
        public function getDate() {
            $this->date = date("Y/m/d h:i:s");
            return $this->date;
        } 

        public function Add() { //ticket_new.php   
            include("../connectDB.php");                                                                                                     
            $this->insert = mysqli_query($this->link, "insert into tickety values (null, '$this->subject', 
            '$this->desc', '".$this->getCategoryId()."', 
            '".$this->getUserId()."', 3, 1, 0, '".$this->getDate()."', 0)");
            if($this->insert) 
                echo "Přidán nový ticket.";
            else 
                echo "!!!";
        }

        public function Delete() {

        }
        public function ChangeStatus() {

        }
        public function Change() {

        }

       

        
    }

    
?>